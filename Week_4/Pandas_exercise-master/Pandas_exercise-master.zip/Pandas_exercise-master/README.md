
# Welcome to Pandas Tutorial

It is the updated version of [**Brandon’s Pandas Tutorial**](https://www.youtube.com/watch?v=5JnMutdy6Fw) from 2015. One of the best Pandas tutorials out there (even creators of this course went through this tutorial :)).

The first instance of this tutorial was delivered at PyCon 2015 in Montréal.

The data for the tutorial can be downloaded from [**here**](https://learningimages.s3.amazonaws.com/Data%20BC/Statistical%20Modelling%20in%20Python/imdb_pandas.zip).
