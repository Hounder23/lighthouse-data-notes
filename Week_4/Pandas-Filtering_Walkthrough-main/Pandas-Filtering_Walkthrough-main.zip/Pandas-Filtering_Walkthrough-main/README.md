# Pandas-Filtering_Walkthrough

1. Download the Jupyter Notebook file: pandas_filtering.ipynb 
2. Download the data file: gapminder.csv
3. Follow along with the instructions in the Jupyter Notebook and execute the cell blocks. 
